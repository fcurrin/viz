var all_data = {
    "1990": {
        "Houston": 1.7, 
        "New York": 7.3, 
        "Los Angeles": 3.5, 
        "Chicago": 2.8
    }, 
    "2016": {
        "Houston": 2.3, 
        "New York": 8.5, 
        "Los Angeles": 4.0, 
        "Chicago": 2.7
    }
};
var min_year = 1990;
var max_year = 2016;